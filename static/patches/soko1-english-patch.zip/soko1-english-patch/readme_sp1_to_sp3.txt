Sokoban 1 (PC-8801) SP1 Patch to SP3 (PC-8801 SR) (a.k.a. English version with music)

We have created a common additional patch that can be applied to SP1.
This patch plays the same music as the "MULTI 8" version.

Since this program is for N88-BASIC Ver.2 only, it works only with PC-8801mkIISR or later models.

Scenes in which music is played
1. When each warehouse is solved.
2. When the game is over
3. When the final warehouse is solved.

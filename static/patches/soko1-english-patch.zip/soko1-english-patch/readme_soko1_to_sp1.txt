Sokoban 1 (PC-8801) Patch to SP1 (a.k.a. English version)

These changes are for the Tape version source code.

Because I need permission to distribute the original source code I can share only the changes in patch format.

2022-06-02 Carlos: I remember that the question to go to the next stage is displayed without clear the map. In the new version is clear first. Taka.: work the same as the MULTI8 version so that the screen is erased first.

2022-06-01 Taka.:

By default, the system starts up in English display.
Press the [O] key on the title screen to enter the options mode.
[ESC] key to quit program.

** How to operate the Option Mode **

Press the [1] key to switching game modes. Default is Reverse wall.
Press the [2] key to change the display language. Default is English.
Press the [3] key to toggle the beep sound On/Off. Default is Off.
Press the [4] key to change the warehouse number colour. Default is Pink.
Press the [ESC] key to return to the previous screen.

** Key operations added to the game **

The [f.2] key can be used to select a warehouse.
Enter the option mode with the [f.3] key.
When you return to the game with the [ESC] key
Restart if the game mode is switched.
Otherwise, you can continue from the state before interruption.

[ESC] key to quit program.
